﻿using UnityEngine;
using System.Collections;

public class Character_Collision_Manager : MonoBehaviour {
    public float Strength = 30F;

    private Rigidbody _puzzleCube = null;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
        if (Input.GetButtonUp("Fire1") &&
            _puzzleCube != null)
        {
            _puzzleCube = null;
        }
        
        if (_puzzleCube != null &&
            Input.GetButton("Fire1"))
        {
         /*   Vector3 force = gameObject.GetComponent<Character_Motor>().moveVector;

            force.y = 0;
            force *= Strength;
            _puzzleCube.AddForce(force);*/
        }
	}

    void OnControllerColliderHit(ControllerColliderHit hit)
    {
        if (_puzzleCube == null &&
            hit.gameObject.tag == "PuzzleCube" &&
            Input.GetButtonDown("Fire1"))
        {
            _puzzleCube = hit.rigidbody;
            _puzzleCube.transform.parent.
        }
    }
}
